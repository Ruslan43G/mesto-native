import React from 'react';
//компонент футер
export default function Footer () {
    return (
        <footer className="footer">
           <p className="footer__copyright">&copy; 2020 Руслан Тихомиров</p>
       </footer>
    )
}